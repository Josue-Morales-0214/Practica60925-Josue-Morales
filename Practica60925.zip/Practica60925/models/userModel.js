let users = []; // { id, username, email, password }

let nextId = 1;

function createUser({ username, email, password }) {
  const user = { id: nextId++, username, email, password };
  users.push(user);
  return user;
}

function findByEmailOrUsername(identifier) {
  return users.find(
    u => u.email === identifier || u.username === identifier
  );
}

function updatePassword(userId, newPassword) {
  const user = users.find(u => u.id === userId);
  if (user) {
    user.password = newPassword;
    return true;
  }
  return false;
}

module.exports = { createUser, findByEmailOrUsername, updatePassword, users };
