let tokens = []; 
// { token, userId, status }

function addToken({ token, userId }) {
  const newToken = { token, userId, status: "Active" };
  tokens.push(newToken);
  return newToken;
}

function findToken(token) {
  return tokens.find(t => t.token === token);
}

function markTokenUsed(token) {
  const t = findToken(token);
  if (t) t.status = "Used";
  return t;
}

module.exports = { addToken, findToken, markTokenUsed, tokens };
