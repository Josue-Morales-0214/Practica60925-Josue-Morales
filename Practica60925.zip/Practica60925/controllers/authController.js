const crypto = require('crypto');
const userModel = require('../models/userModel');
const tokenModel = require('../models/tokenModel');

// Registro
function register(req, res) {
  const { username, email, password } = req.body;
  const user = userModel.createUser({ username, email, password });
  res.json({ message: "Usuario registrado", user });
}

// Login
function login(req, res) {
  const { identifier, password } = req.body;
  const user = userModel.findByEmailOrUsername(identifier);
  if (!user || user.password !== password) {
    return res.status(401).json({ message: "Credenciales inválidas" });
  }
  res.json({ message: "Login exitoso", user });
}

// Forgot password → genera token
function forgotPassword(req, res) {
  const { identifier } = req.body;
  const user = userModel.findByEmailOrUsername(identifier);

  if (!user) {
    return res.json({ message: "Si existe el usuario, se envió correo (simulado)" });
  }

  const token = crypto.randomBytes(8).toString('hex'); // token sencillo
  tokenModel.addToken({ token, userId: user.id });

  // Enlace simulado
  const link = `http://localhost:3000/api/auth/reset-password?token=${token}`;
  res.json({ message: "Token generado", link });
}

// Reset password
function resetPassword(req, res) {
  const { token } = req.query;
  const { password } = req.body;

  const t = tokenModel.findToken(token);
  if (!t || t.status !== "Active") {
    return res.status(400).json({ message: "Token inválido o ya usado" });
  }

  userModel.updatePassword(t.userId, password);
  tokenModel.markTokenUsed(token);

  res.json({ message: "Contraseña actualizada, token marcado como usado" });
}

module.exports = { register, login, forgotPassword, resetPassword };
